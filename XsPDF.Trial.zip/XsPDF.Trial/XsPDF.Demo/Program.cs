﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XsPDF.Pdf;

namespace XsPDF.Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            //PdfToImageDemo.ConvertPdfToImage();
            //BarcodeDemo.AddQRCodeToPDF();
            //ChartDemo.AddAreaChartToPDF();
            //CreatePDFDemo.CreatePDFFromImage();
            //DocumentProtectDemo.ProtectDocument();
            ExtractDemo.ExtractTextFromPDF();
            //InsertToPDFDemo.CreateLongParagraphToPDF();
            //ProcessDemo.CombinePDFs();
            //MSChartDemo.InsertMSChartToPDF();
            //MSChartDemo.CreateMSRangeColumnChart();
            //SignPDFDemo.SignPDF();
           
        }
    }
}
