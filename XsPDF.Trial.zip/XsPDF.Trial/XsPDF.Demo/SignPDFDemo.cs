﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using XsPDF.Sign;

namespace XsPDF.Demo
{
    class SignPDFDemo
    {
        public static void SignPDF()
        {
            //Load the pfx certificate file with password
            PdfCertificate cert = new PdfCertificate("demo.pfx", "your-password");
            PdfSigner signer = new PdfSigner("demo.pdf", cert);
            //Input the signature info
            signer.ContactInfo = "your contact information";            
            signer.Location = "your location";           
            signer.Reason = "your reason";
            signer.FieldName = "XsPDF Sign";
            //Sign in target page
            signer.PageId = 0;
            //Sign in target area in page
            signer.Rect = new Rectangle(100, 100, 100, 50);
            //Choose the target algorithm from SHA1, SHA26, SHA512
            signer.SignatureAlgorithm = SignatureAlgorithm.SHA256;
            //Set signature appearance to text style
            signer.SignatureShowingType = SignatureShowingType.Description;

            signer.Sign("text-sign.pdf");
        }

        public static void AddImageSignatureToPDF()
        {
            //Load the pfx certificate file with password
            PdfCertificate cert = new PdfCertificate("demo.pfx", "your-password");
            PdfSigner signer = new PdfSigner("demo.pdf", cert);
            //Input the image file showing as signature
            signer.SignatureImagePath = "demo.jpg";
            signer.FieldName = "XsPDF Sign";
            signer.PageId = 0;
            signer.Rect = new Rectangle(100, 100, 100, 50);
            signer.SignatureAlgorithm = SignatureAlgorithm.SHA256;
            //Set signature appearance to image style
            signer.SignatureShowingType = SignatureShowingType.Image;

            signer.Sign("image-sign.pdf");
        }

        public static void AddImageAndTextSignatureToPDF()
        {
            //Load the pfx certificate file with password
            PdfCertificate cert = new PdfCertificate("demo.pfx", "your-password");
            PdfSigner signer = new PdfSigner("demo.pdf", cert);
            //Input the image file showing as signature
            signer.SignatureImagePath = "demo.jpg";
            //Input the signature info
            signer.ContactInfo = "your contact information";
            signer.Location = "your location";
            signer.Reason = "your reason";
            signer.FieldName = "XsPDF Sign";
            signer.PageId = 0;
            signer.Rect = new Rectangle(100, 100, 100, 50);
            signer.SignatureAlgorithm = SignatureAlgorithm.SHA256;
            //Set signature appearance to image&text style
            signer.SignatureShowingType = SignatureShowingType.ImageAndDescription;

            signer.Sign("sign.pdf");
        }

        public static void InvisibleSignPDF()
        {
            //Load the pfx certificate file with password
            PdfCertificate cert = new PdfCertificate("demo.pfx", "your-password");
            PdfSigner signer = new PdfSigner("demo.pdf", cert);           
            signer.ContactInfo = "your contact information";
            signer.Location = "your location";
            signer.Reason = "your reason";
            signer.FieldName = "XsPDF Sign";
            signer.PageId = 0;
            //Set width and height of signature area to 0
            signer.Rect = new Rectangle(0, 0, 0, 0);
            signer.SignatureAlgorithm = SignatureAlgorithm.SHA256;
            signer.SignatureShowingType = SignatureShowingType.Description;

            signer.Sign("invisible-sign.pdf");
        }

        public static void MultipleSignPDF()
        {
            //Add first signature
            PdfCertificate cert1 = new PdfCertificate("demo1.pfx", "your-password");
            PdfSigner signer = new PdfSigner("demo.pdf", cert1);            
            signer.ContactInfo = "contact1";
            signer.Location = "location1";
            signer.Reason = "reason1";
            signer.FieldName = "XsPDF Sign1";
            signer.PageId = 0;
            signer.Rect = new Rectangle(100, 100, 100, 50);
            signer.SignatureAlgorithm = SignatureAlgorithm.SHA256;
            signer.SignatureShowingType = SignatureShowingType.Description;
            signer.Sign("demo.pdf");

            //Add second signature
            PdfCertificate cert2 = new PdfCertificate("demo2.pfx", "your-password");
            signer = new PdfSigner("demo.pdf", cert1);
            signer.ContactInfo = "contact2";
            signer.Location = "location2";
            signer.Reason = "reason2";
            signer.FieldName = "XsPDF Sign2";
            signer.PageId = 1;
            signer.Rect = new Rectangle(300, 50, 100, 50);
            signer.SignatureAlgorithm = SignatureAlgorithm.SHA256;
            signer.SignatureShowingType = SignatureShowingType.Description;
            signer.Sign("demo.pdf");
        }

    }
}
